(() => {
 const button = document.querySelector('.menu-toggle');
 const nav = document.querySelector('#main-nav');
 if (!button || !nav) return;
 button.hidden = false;
 document.body.classList.add('nav-ready');
 const close = () => { nav.classList.remove('is-open'); button.setAttribute('aria-expanded', 'false'); };
 button.addEventListener('click', () => { const open = button.getAttribute('aria-expanded') !== 'true'; nav.classList.toggle('is-open', open); button.setAttribute('aria-expanded', String(open)); });
 document.addEventListener('keydown', event => { if (event.key === 'Escape' && button.getAttribute('aria-expanded') === 'true') { close(); button.focus(); } });
 matchMedia('(min-width: 761px)').addEventListener('change', close);
})();

// Native radio controls provide Tab and arrow-key navigation.
(() => {
 const choices = document.querySelectorAll('input[name="discovery-view"]');
 if (!choices.length) return;
 const update = () => {
  const value = document.querySelector('input[name="discovery-view"]:checked').value;
  document.getElementById('search-view').hidden = value !== 'search';
  document.getElementById('ai-view').hidden = value !== 'ai';
 };
 choices.forEach(choice => choice.addEventListener('change', update));
 update();
})();
