(() => {
 const filter=document.querySelector('#archive-category');if(!filter)return;
 const entries=[...document.querySelectorAll('.archive-entry')],message=document.querySelector('#archive-storage'),key='searchLabExperimentStatuses.v1';
 let saved={};try{saved=JSON.parse(localStorage.getItem(key)||'{}')||{};}catch{message.textContent='Local planning statuses could not be loaded. Published records remain available.';}
 filter.addEventListener('change',()=>{let count=0;entries.forEach(e=>{e.hidden=!!filter.value&&!JSON.parse(e.dataset.categories).includes(filter.value);if(!e.hidden)count++;});document.querySelector('#archive-count').textContent=`${count} experiment${count===1?'':'s'} in this view`;});
 document.querySelectorAll('[data-status]').forEach(select=>{if([...select.options].some(o=>o.value===saved[select.dataset.status]))select.value=saved[select.dataset.status];select.addEventListener('change',()=>{const next={...saved,[select.dataset.status]:select.value};try{localStorage.setItem(key,JSON.stringify(next));saved=next;message.textContent='Working status saved locally. Published status and findings are unchanged. Local browser data can be lost.';}catch{message.textContent='Browser storage is unavailable. This status change has not been saved.';}});});
})();
