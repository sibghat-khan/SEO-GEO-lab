(() => {
 const app=document.getElementById('xray-app'); if(!app) return;
 const frame=document.getElementById('xr-frame');
 const wrap=document.getElementById('xr-frame-wrap');
 const inspector=document.getElementById('xr-inspector');
 const heading=document.getElementById('xr-inspector-title');
 const body=document.getElementById('xr-note-body');
 const close=document.getElementById('xr-close-note');
 const notes=window.xrayNotes;
 let mode='normal',review='before',width='desktop',selected=null,trigger=null,observer=null;
 const element=(tag,text)=>{const n=document.createElement(tag);if(text)n.textContent=text;return n;};
 function fit(){const doc=frame.contentDocument;if(doc?.body)frame.style.height=Math.ceil(doc.body.getBoundingClientRect().height+2)+'px';}
 function resetNote(){selected=null;trigger=null;heading.textContent='Choose an inspection point.';body.replaceChildren(element('p','Select an outlined element on the sample or a topic below.'));document.getElementById('xr-note-status').textContent='Six deliberate issues; four retained checks.';close.hidden=true;highlight();}
 function highlight(){
  document.querySelectorAll('[data-xr-select]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.xrSelect===selected)));
  frame.contentDocument?.querySelectorAll('[data-point]').forEach(n=>n.classList.toggle('selected',n.dataset.point===selected));
  frame.contentDocument?.querySelectorAll('[data-inspect]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.inspect===selected)));
 }
 function showNote(id,focus=true,source=null){
  const note=notes.find(n=>n.id===id);if(!note)return;
  selected=id;if(source)trigger=source;
  heading.textContent=String(note.number).padStart(2,'0')+' / '+note.title;
  document.getElementById('xr-note-status').textContent=note.issue?(review==='before'?'Deliberate issue · before review':'Recommended improvement applied · after review'):'Retained check · not counted as an issue';
  body.replaceChildren();
  [['What I found',note[review]],['Why it matters',note.why],['What I would recommend',note.issue&&review==='after'?'Keep this correction in place. '+note.recommend:note.recommend],['How the improvement would be checked',note.check]].forEach(([title,text])=>{const block=element('div');block.append(element('h3',title),element('p',text));body.append(block);});
  close.hidden=false;highlight();
  if(focus){heading.focus({preventScroll:true});inspector.scrollIntoView({block:'nearest',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});}
 }
 notes.forEach(note=>{const b=element('button',String(note.number).padStart(2,'0')+' · '+note.title);b.type='button';b.dataset.xrSelect=note.id;b.setAttribute('aria-controls','xr-note-body');b.setAttribute('aria-pressed','false');const small=element('small',note.issue?'REVIEW ISSUE':'RETAINED CHECK');b.append(small);document.getElementById('xr-note-index').append(b);});
 document.getElementById('xr-note-index').addEventListener('click',event=>{const b=event.target.closest('[data-xr-select]');if(b)showNote(b.dataset.xrSelect,true,b);});
 close.addEventListener('click',()=>{const previous=trigger;resetNote();if(previous?.isConnected)previous.focus();else document.querySelector('input[name="xr-mode"]:checked').focus();});
 inspector.addEventListener('keydown',event=>{if(event.key==='Escape'&&!close.hidden){event.preventDefault();close.click();}});
 function applyMode(){
  app.classList.toggle('is-xray',mode==='xray');
  inspector.hidden=mode!=='xray';
  frame.contentDocument?.body?.classList.toggle('xray',mode==='xray');
  document.getElementById('xr-guidance').textContent=mode==='xray'?'Select an outlined element or use the review-note index. Switch Before / After to compare the same finding.':'Start with the page as a visitor sees it. Switch to X-Ray View to reveal ten inspection points.';
  requestAnimationFrame(fit);
 }
 function announce(){document.getElementById('xr-status').textContent=(review==='before'?'Before SEO Review':'After SEO Review')+', '+(mode==='normal'?'Normal View':'X-Ray View')+', '+(width==='mobile'?'mobile-width preview':'available-width preview')+'. Six deliberately created issues; no live audit.';}
 frame.addEventListener('load',()=>{
  const doc=frame.contentDocument;if(!doc?.body)return;
  applyMode();
  doc.addEventListener('click',event=>{
   const button=event.target.closest('[data-inspect]');if(button){showNote(button.dataset.inspect,true,button);return;}
   const link=event.target.closest('a[href^="#"]');if(link){event.preventDefault();const target=doc.getElementById(link.getAttribute('href').slice(1));if(target){if(target.tagName==='DETAILS')target.open=true;target.setAttribute('tabindex','-1');target.focus({preventScroll:true});requestAnimationFrame(()=>{fit();target.scrollIntoView({block:'nearest',behavior:'smooth'});});}}
  });
  observer?.disconnect();observer=new ResizeObserver(fit);observer.observe(doc.body);
  doc.querySelectorAll('img').forEach(img=>img.addEventListener('load',fit));
  if(selected)showNote(selected,false);fit();
 });
 app.addEventListener('change',event=>{
  const input=event.target;if(input.name==='xr-mode'){mode=input.value;applyMode();}
  if(input.name==='xr-review'){review=input.value;document.getElementById('xr-state-label').textContent=review==='before'?'Before review':'After review';frame.srcdoc=window.xrayPages[review];}
  if(input.name==='xr-width'){width=input.value;wrap.classList.toggle('mobile-preview',width==='mobile');requestAnimationFrame(fit);}
  announce();
 });
 window.addEventListener('resize',fit);
 frame.srcdoc=window.xrayPages.before;
 announce();
})();
