(() => {
  const host=document.querySelector('#journey-workspace');
  if(!host)return;
  const data=window.searchLabJourneys;
  let persona=0,stage=0;
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icons=['<circle cx="12" cy="9" r="5"/><path d="M9 15v3h6v-3M10 21h4"/>','<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>','<path d="M3 4h7l2 2 2-2h7v15h-7l-2 2-2-2H3zM12 6v15"/>','<path d="m12 2 8 4v6c0 5-8 10-8 10S4 17 4 12V6zM8 12l3 3 5-6"/>','<path d="M3 6h18v13H3zM3 6l9 7 9-7"/>','<path d="M4 3v18h18M8 17v-4M13 17V8M18 17V4"/>'];
  const subtitles=['Identify a need','Find possible answers','Compare approaches','Assess providers','Take a useful action','Review the evidence'];
  host.innerHTML=`<ol class="journey-route" aria-label="Explore six journey stages">${data[0].stages.map((s,i)=>`<li><button type="button" id="journey-stage-${i}" data-stage="${i}" aria-controls="journey-detail" aria-expanded="false"><span class="journey-symbol"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[i]}</svg></span><span class="journey-step-number">0${i+1}</span><strong>${s.name}</strong><small>${subtitles[i]}</small></button></li>`).join('')}</ol><div id="journey-desktop-detail"></div><p id="journey-announcement" class="journey-sr" role="status" aria-live="polite"></p>`;
  const detail=document.createElement('section');detail.id='journey-detail';detail.className='journey-detail';detail.setAttribute('aria-label','Selected journey stage');
  const media=window.matchMedia('(max-width:760px)');
  function position(){const parent=media.matches?host.querySelectorAll('.journey-route>li')[stage]:document.querySelector('#journey-desktop-detail');if(detail.parentNode!==parent)parent.append(detail);}
  function render(){const p=data[persona],s=p.stages[stage];document.querySelector('#journey-persona-description').textContent=p.persona;
    host.querySelectorAll('[data-stage]').forEach((b,i)=>{b.setAttribute('aria-expanded',String(i===stage));if(i===stage)b.setAttribute('aria-current','step');else b.removeAttribute('aria-current');});
    detail.setAttribute('aria-labelledby',`journey-stage-${stage}`);
    detail.innerHTML=`<header><p class="eyebrow">${esc(p.name.toUpperCase())} / ${String(stage+1).padStart(2,'0')} / ${s.name.toUpperCase()}</p><h2>${esc(s.thinking)}</h2></header><div class="journey-detail-grid"><div><p class="eyebrow">WHAT THEY MAY SEARCH FOR</p><blockquote>“${esc(s.query)}”</blockquote><h3>Content that could help</h3><ul>${s.content.map(c=>`<li>${esc(c)}</li>`).join('')}</ul></div><div><h3>My approach · SEO / GEO / AEO</h3><p>${esc(s.approach)}</p><h3>How the business could measure it</h3><p>${esc(s.measurement)}</p></div></div><nav class="journey-pagination" aria-label="Move between journey stages"><button type="button" data-back ${stage===0?'disabled':''}>← Previous stage</button><span>${stage+1} of 6</span><button type="button" data-forward ${stage===5?'disabled':''}>Next stage →</button></nav>`;
    position();
    detail.querySelector('[data-back]').onclick=()=>select(stage-1,true);
    detail.querySelector('[data-forward]').onclick=()=>select(stage+1,true);
    document.querySelector('#journey-announcement').textContent=`${p.name}: ${s.name} selected. Stage details updated.`;
  }
  function select(i,focus=false){stage=i;render();if(focus){const b=document.querySelector(`#journey-stage-${stage}`);b.focus();b.scrollIntoView({block:'nearest'});}}
  host.querySelectorAll('[data-stage]').forEach(b=>b.onclick=()=>select(Number(b.dataset.stage)));
  document.querySelectorAll('[name="journey-persona"]').forEach(r=>r.addEventListener('change',()=>{persona=Number(r.value);render();}));
  media.addEventListener('change',position);
  render();
})();
