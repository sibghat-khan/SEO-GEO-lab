(() => {
  const host = document.querySelector('#decision-app');
  if (!host) return;
  const scenarios = window.searchLabDecisions;
  const selections = new Map(), expanded = new Map();
  let current = 0;
  const esc = s => s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function render(focus = false) {
    const s = scenarios[current], selected = selections.get(s.id);
    host.innerHTML = `<nav class="decision-tabs" aria-label="Choose a scenario">${scenarios.map((x,i) => `<button type="button" data-scenario="${i}" aria-pressed="${i===current}"><span>0${i+1}</span>${esc(x.name)}</button>`).join('')}</nav><article class="decision-case"><header><p class="eyebrow">SCENARIO ${current+1} / ${scenarios.length}</p><h2 id="decision-question" tabindex="-1">${esc(s.question)}</h2><p>${esc(s.context)}</p></header><div class="decision-columns"><aside class="decision-evidence"><p class="eyebrow">ON THE DESK / FICTIONAL EVIDENCE</p><ul>${s.evidence.map(x=>`<li>${esc(x)}</li>`).join('')}</ul><p class="decision-small">These clues support hypotheses. They do not establish a cause.</p></aside><section class="decision-options"><h3>What would you investigate first?</h3><p>Choose a starting point. You can explore every path; there is no score.</p><div class="decision-choices">${s.choices.map((x,i)=>`<button type="button" data-choice="${i}" aria-pressed="${selected===i}" aria-controls="decision-response"><span>${String.fromCharCode(65+i)}</span>${esc(x.title)}<span aria-hidden="true">↗</span></button>`).join('')}</div><div id="decision-response" role="status" aria-live="polite" aria-atomic="true"></div></section></div><section class="decision-process"><p class="eyebrow">HOW I WOULD APPROACH IT</p><h3>An investigation, step by step.</h3><p>Open each step to see what I would check and how the evidence changes the route.</p><ol class="decision-tree">${s.steps.map((x,i)=>`<li><details data-step="${i}" ${expanded.get(s.id)?.has(i)?'open':''}><summary><span class="decision-node">${i+1}</span>${esc(x.title)}</summary><div class="decision-step-body"><p><strong>Investigate</strong>${esc(x.check)}</p><p class="decision-branch"><strong>Follow the evidence →</strong>${esc(x.branch)}</p></div></details></li>`).join('')}</ol><div class="decision-takeaway"><p class="eyebrow">PRACTICAL TAKEAWAY</p><p>${esc(s.takeaway)}</p></div></section><div class="decision-pager"><button type="button" data-prev ${current===0?'disabled':''}>← Previous scenario</button><button type="button" data-next>${current===scenarios.length-1?'Finish the workshop ↗':'Next scenario →'}</button></div></article>`;
    if(selected!==undefined) response(selected);
    host.querySelectorAll('[data-scenario]').forEach(b=>b.addEventListener('click',()=>{current=Number(b.dataset.scenario);render(true);}));
    host.querySelectorAll('[data-choice]').forEach(b=>b.addEventListener('click',()=>{
      const index=Number(b.dataset.choice);selections.set(s.id,index);
      host.querySelectorAll('[data-choice]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));
      response(index);
    }));
    host.querySelectorAll('[data-step]').forEach(d=>d.addEventListener('toggle',()=>{const set=expanded.get(s.id)||new Set();const i=Number(d.dataset.step);d.open?set.add(i):set.delete(i);expanded.set(s.id,set);}));
    host.querySelector('[data-prev]').addEventListener('click',()=>{if(current>0){current--;render(true);}});
    host.querySelector('[data-next]').addEventListener('click',()=>{if(current<scenarios.length-1){current++;render(true);}else document.querySelector('#workshop-end').focus();});
    if(focus)host.querySelector('#decision-question').focus();
  }
  function response(index){const c=scenarios[current].choices[index];host.querySelector('#decision-response').innerHTML=`<div class="decision-feedback"><p class="eyebrow">A CLOSER LOOK AT THIS CHOICE</p><h4>${esc(c.title)}</h4><p><strong>Strength</strong>${esc(c.strength)}</p><p><strong>Limitation</strong>${esc(c.limit)}</p><a href="#decision-process-link">Explore my investigation process ↓</a></div>`;host.querySelector('.decision-process').id='decision-process-link';}
  render();
})();
