(() => {
 const root = document.getElementById('discovery-simulator');
 if (!root) return;
 const data = window.searchLabSimulator;
 const annotations = window.searchLabAnnotations;
 const industry = document.getElementById('sim-industry');
 const question = document.getElementById('sim-question');
 const title = document.getElementById('sim-note-title');
 const note = document.getElementById('sim-note-body');
 const close = document.getElementById('sim-close-note');
 let current, trigger;
 const el = (tag, text, className) => { const n = document.createElement(tag); if (text) n.textContent = text; if (className) n.className = className; return n; };
 const explainButton = (label, key, source) => { const b = el('button', label, 'explain'); b.type = 'button'; b.dataset.note = key; if (source) b.dataset.source = source; b.setAttribute('aria-controls','sim-explanation'); return b; };
 function resetNote() {
  title.textContent = 'Look closer.';
  note.replaceChildren(el('p','Choose an explanation in either panel to see what it means, why it matters, and how I approach improving it.'));
  close.hidden = true;
  root.querySelectorAll('[data-note]').forEach(b => b.removeAttribute('aria-expanded'));
  trigger = null;
 }
 function citationText(text) {
  const p = el('p');
  for (const part of text.split(/(\[[ABC]\])/)) {
   if (/^\[[ABC]\]$/.test(part)) {
    const b = explainButton(part,'citations',part[1]);
    b.classList.add('sim-citation'); b.setAttribute('aria-label','Inspect illustrative source '+part[1]); p.append(b);
   } else p.append(document.createTextNode(part));
  }
  return p;
 }
 function render() {
  current = data.find(d => d.id === industry.value).questions.find(q => q.id === question.value);
  document.getElementById('sim-query').textContent = current.question;
  const results = document.getElementById('sim-results'); results.replaceChildren();
  current.sources.forEach(source => {
   const article = el('article',null,'sim-result');
   article.append(el('p',source.type,'sim-result-type'),el('p',source.url+' · placeholder URL','sim-url'));
   const heading = el('h3'); const button = explainButton(source.title,'relevance',source.id); button.classList.add('sim-result-title'); heading.append(button); article.append(heading,el('p',source.description),explainButton('Page relevance ↗','relevance',source.id)); results.append(article);
  });
  document.getElementById('sim-answer').replaceChildren(citationText(current.answer));
  document.getElementById('sim-brand').replaceChildren(...citationText(current.brand).childNodes);
  const sources = document.getElementById('sim-sources'); sources.replaceChildren();
  current.sources.forEach(source => {
   const b = explainButton('['+source.id+'] '+source.title,'citations',source.id); b.classList.add('sim-source'); sources.append(b);
  });
  document.getElementById('sim-finance-context').hidden = industry.value !== 'finance';
  resetNote();
  if (!matchMedia('(prefers-reduced-motion: reduce)').matches) root.querySelectorAll('.sim-panel-body').forEach(panel => panel.animate([{opacity:.55},{opacity:1}],{duration:180,easing:'ease-out'}));
  document.getElementById('sim-status').textContent = data.find(d => d.id===industry.value).name+': both search experiences updated for '+current.question;
 }
 function updateIndustry() {
  question.replaceChildren();
  data.find(d => d.id === industry.value).questions.forEach(q => { const o=el('option',q.question);o.value=q.id;question.append(o); });
  render();
 }
 data.forEach(d => {const o=el('option',d.name);o.value=d.id;industry.append(o);});
 industry.addEventListener('change',updateIndustry);
 question.addEventListener('change',render);
 root.addEventListener('click',event => {
  const button=event.target.closest('[data-note]'); if(!button) return;
  const a=annotations[button.dataset.note]; if(!a) return;
  const source=current.sources.find(s=>s.id===button.dataset.source);
  trigger=button;
  root.querySelectorAll('[data-note]').forEach(b=>b.removeAttribute('aria-expanded'));
  button.setAttribute('aria-expanded','true');
  title.textContent=a.title;
  note.replaceChildren();
  const context=el('div',null,'sim-context');
  context.append(el('p',current.question,'sim-context-question'));
  if(source) {
   context.append(el('strong','Illustrative source '+source.id+': '+source.title),el('p',source.url+' · fictional placeholder'));
   context.append(el('blockquote',source.excerpt));
   context.append(el('small','Written example of supporting content; not a retrieved page.'));
  } else if(button.dataset.note==='intent') context.append(el('p',current.intent));
  note.append(context);
  const grid=el('div',null,'sim-note-grid');
  [['What it means',a.meaning],['Why it matters',a.why],['How I approach it',a.approach]].forEach(([h,p])=>{const block=el('div');block.append(el('h3',h),el('p',p));grid.append(block);});
  note.append(grid); close.hidden=false;
  title.focus({preventScroll:true});
  document.getElementById('sim-explanation').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'nearest'});
 });
 close.addEventListener('click',()=>{const previous=trigger;resetNote();previous?.focus();});
 document.getElementById('sim-explanation').addEventListener('keydown',event=>{if(event.key==='Escape'&&!close.hidden){event.preventDefault();close.click();}});
 updateIndustry();
})();
