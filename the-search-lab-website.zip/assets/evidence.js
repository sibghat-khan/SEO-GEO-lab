(() => {
 const archive=document.querySelector('.ev-archive');
 if(archive){
  const filter=()=>{
   const selected=archive.querySelector('input[name="contribution"]:checked').value;
   let count=0;
   archive.querySelectorAll('[data-project]').forEach(card=>{
    const project=window.evidenceProjects.find(p=>p.slug===card.dataset.project);
    const matches=project.contributions.filter(c=>selected==='All contributions'||c.tags.includes(selected));
    card.hidden=!matches.length;if(matches.length)count++;
    const target=card.querySelector('.ev-matches');target.replaceChildren();target.hidden=selected==='All contributions';
    if(selected!=='All contributions'){
     const label=document.createElement('p');label.className='ev-label';label.textContent='From my contribution · '+selected;target.append(label);
     const list=document.createElement('ul');matches.forEach(item=>{const li=document.createElement('li');li.textContent=item.text;list.append(li);});target.append(list);
    }
   });
   archive.querySelector('.ev-filter-status').textContent='Showing '+count+' '+(count===1?'project':'projects')+' · '+selected.toLowerCase();
   archive.querySelector('.ev-empty').hidden=count!==0;
  };
  archive.addEventListener('change',event=>{if(event.target.name==='contribution')filter();});filter();
 }
 const dialog=document.getElementById('evidence-dialog');if(!dialog)return;
 let opener=null;
 const node=(tag,text)=>{const n=document.createElement(tag);if(text)n.textContent=text;return n;};
 const media=document.getElementById('evidence-media');
 function image(src,alt){const img=node('img');img.src=new URL('../../'+src,location.href).href;img.alt=alt;img.addEventListener('error',()=>{const message=node('p','This approved image could not be loaded. Please consult the source note below.');img.replaceWith(message);});return img;}
 function prepare(title,kind,context,source,limit){
  document.getElementById('evidence-title').textContent=title;
  document.getElementById('evidence-kind').textContent=kind;
  document.getElementById('evidence-context').textContent=context;
  document.getElementById('evidence-source').textContent=source;
  document.getElementById('evidence-limit').textContent=limit||'';
  media.replaceChildren();
 }
 document.addEventListener('click',event=>{
  const entry=event.target.closest('[data-evidence]');
  const compare=event.target.closest('[data-comparison]');
  if(entry){
   const data=window.evidenceRecords[entry.dataset.evidence];if(!data)return;
   prepare(data.title,data.kind==='account'?'AUTHOR-SUPPLIED PROJECT ACCOUNT':'PROJECT EVIDENCE',data.context,data.source,data.limit);
   if(data.kind==='image')media.append(image(data.src,data.alt));
   else data.text.split('\n\n').forEach(text=>media.append(node('blockquote',text)));
   opener=entry;dialog.showModal();document.body.classList.add('ev-dialog-open');
  }
  if(compare){
   const data=window.evidenceComparisons[compare.dataset.comparison];if(!data)return;
   prepare(data.title,'BEFORE AND AFTER',data.context,data.source,data.limit||'A comparison shows the supplied versions; it does not establish a performance outcome.');
   const group=node('div');group.className='ev-comparison';
   ['before','after'].forEach(key=>{const col=node('section');col.append(node('h3',data[key].label));if(data.kind==='image')col.append(image(data[key].src,data[key].alt));else col.append(node('p',data[key].text));group.append(col);});media.append(group);
   opener=compare;dialog.showModal();document.body.classList.add('ev-dialog-open');
  }
 });
 dialog.querySelector('[data-close-evidence]').addEventListener('click',()=>dialog.close());
 dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
 dialog.addEventListener('close',()=>{document.body.classList.remove('ev-dialog-open');opener?.focus();});
})();
