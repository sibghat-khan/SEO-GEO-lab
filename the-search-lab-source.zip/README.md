# The Search Lab — foundation release

A dependency-free static website extending the existing portfolio. Open `dist/index.html` directly, or serve `dist/` with any static web server.

## Editing
- `system.css`: shared colours, typography, spacing, layouts, responsive states.
- `navigation.js`: progressive-enhancement mobile menu; Escape closes it.
- `build.py`: shared page shell, header, footer, templates and homepage composition.
- `content/experiences.json`: Lab experience directory.
- `content/site.json`: verified production origin for canonical URLs. Left empty because publication is blocked; configure before going live.
- `original/`: unchanged original six-page portfolio, used as the content source for existing inner pages.
- `dist/`: generated website; no JavaScript framework or build dependency required for hosting.

Run `python3 build.py` then `python3 check.py` from this directory after editing. Manual changes to dist are replaced on build.

## Architecture
Home; Lab directory; Search vs AI discovery; SEO X-Ray; SEO Decision Room; Search Journey; AI Citation Observatory; Experiment Archive; Journal; Work; Exchange My Car; Outcraft; About; Contact.

Future experiences and editorial areas are explicitly marked as previews or in preparation. Their pages use noindex,follow until substantive content is available. No live integrations, simulated results, or invented performance metrics have been added.

Existing page URLs and all five inner-page bodies are preserved exactly. The homepage retains existing project summaries, services, experience details and destination links while introducing the new identity. Original styles are retained in a shared compatibility stylesheet beneath the design system, preserving disclosure and case-study layouts.

## Validation
14 pages pass HTML nesting, unique ID, single H1, title/description, internal destination and fragment checks. Automated comparison verifies exact preservation of the five existing inner-page bodies. Desktop homepage and Work layouts inspected in browser. Mobile (390px) and tablet (820px) homepage widths confirmed without horizontal overflow. Mobile navigation opens and Escape closes it. The retained Exchange My Car disclosure expands correctly. Checks are representative, not an exhaustive browser/device audit.

## Publication
Existing Sites identity retained. Repository access was blocked by automatic approval review; nothing was deployed. Canonical origin awaits a verified production URL.

## Hero update
The homepage now uses the requested business-impact headline, exact supporting copy, four professional-background figures, and a search/AI comparison preview. Edit `content/hero.html` for hero copy; shared CSS and navigation.js provide its styling and native radio interactions. The full simulator remains a planned experience and is labelled accordingly.

Verified at 1366 × 768: experience strip bottom at 710px, with headline and CTAs visible together. Verified at 390px: no horizontal overflow and figures before preview. Both CTA destinations were opened successfully; radio switching and ArrowLeft keyboard switching were tested. Original inner-page preservation checks continue to pass.

## Discovery Simulator — implemented
The full simulator is now available at `dist/lab/discovery/index.html`. It supersedes the earlier planned-simulator status in this release history. Homepage and Lab directory links now point to the active experience.

- Three industries, two questions each, and paired traditional/AI-style views.
- `content/simulator.json` stores deterministic scenarios and fictional sources; `content/annotations.json` stores seven explanations.
- `content/simulator.html` contains the page layout; `simulator.js` handles selectors, citations, annotation focus, and reset behaviour.
- Data is bundled as a local script so the exported website also works directly from files without fetch, APIs, accounts, or an internet connection.
- All references use fictional `.example` placeholders. Finance risk terminology is checked against Investor.gov, separately linked as editorial background and never represented as a simulated citation.
- Verified all six scenarios, all seven explanations, source A/B/C excerpts, keyboard Enter/Escape, state reset, final case-study CTA, and 390px stacked panels without horizontal overflow. Browser console reported no errors.
- Shared page structure and all five original inner-page bodies still pass preservation and link checks.

Publication remains blocked by the earlier repository-access approval restriction. This release is delivered locally.

## SEO X-Ray — implemented
Available at `dist/lab/seo-x-ray/index.html`. This supersedes its former preview status. Homepage and Lab directory links now identify it as an available experience.

- Normal / X-Ray views, Before / After review states, and Desktop / Mobile preview widths.
- Six deliberate issues: vague metadata, competing primary headings, unrelated canonical, vague internal links, repetitive service copy, and generic FAQ answers.
- Four retained checks: descriptive alt text, intentional sample noindex, minimal matching Service data, and mobile usability.
- Ten inspection points each include finding, rationale, recommendation, and verification method. No SEO score, indexing claim, or ranking guarantee.
- Fictional RelayDesk landing page is isolated in a sandboxed srcdoc iframe. Its intentional defects, canonical, and noindex directive do not change the portfolio document. The sample uses no external services or user data.
- Sample FAQs expand, internal links open supporting workflow notes, and the sample CTA opens a labelled demonstration rather than submitting an enquiry.

Source: `content/xray.html`, `content/xray-sample.html`, `content/xray-notes.json`, `xray-sample.css`, `xray_build.py`, and `xray.js`. The shared build generates local example data and an embedded SVG workflow illustration. All changes are included in the editable source archive.

Validation: all ten notes checked in both review states with all four explanation fields; source and browser checks verify two H1s before and one after, the corrected canonical, sample links, FAQ and CTA behaviour. Enter activates review notes, Escape closes them. At 390px, the outer page and embedded sample have no horizontal overflow. Existing five inner-page bodies remain unchanged. Browser automation emitted a MutationObserver error during an iframe interaction; the affected interaction was verified through the accessibility controls, and subsequent functional checks completed.

## The Evidence Room — implemented
`dist/work/index.html` is now The Evidence Room. The existing project URLs remain intact. Both projects have the six requested chapter headings, while every original case-study text fragment is preserved verbatim. Existing headings appear as subheadings, and the original lesson disclosures remain usable. Outcraft also includes a first-person reflection taken verbatim from the previously supplied full project account.

The archive and homepage use editorial project rows with name, industry, role, challenge, contribution areas, and case-study links. The five contribution filters expose matching passages from the existing contribution lists. Analytics and Growth Marketing currently match Outcraft only; no unsupported work is assigned to Exchange My Car.

### Evidence availability
No approved screenshots, reporting exports, or paired copy/image versions were found in the available portfolio files or original case-study attachments. The published reader displays only excerpts from the existing author-supplied accounts, explicitly distinguished from independent implementation records and verified performance reports. No extra client projects, invented results, screenshots, or comparisons have been added.

The image/report viewer and side-by-side before/after renderer are implemented but remain unpublished for these projects until approved assets are configured. Separate engineering fixtures tested those states; fixtures are excluded from both deliverable archives.

### Adding approved material
Edit `content/evidence-projects.json`. Place approved images in `content/evidence-media/`; the build copies them to `dist/assets/evidence/`. Each evidence entry needs an id, approved:true, kind (image or report), title, source, context (what it demonstrates), and limit (what it does not establish). Images need src relative to dist (for example assets/evidence/approved-file.png) and alt. A thumbnail:true flag shows an approved image on the project card; caption is optional. Report entries need exact text.

Comparison entries require approved:true, an id, kind (image or text), title, source, context, and before/after objects. Each object needs a descriptive label plus either src and alt or the genuine text version. Use labels or context to identify dates, page versions, and comparison limits. Nothing renders solely because a file exists: its approved record must be configured.

Source: `evidence_build.py`, `evidence.js`, shared `system.css`, and `content/evidence-projects.json`. The shared build invokes the Evidence Room renderer after producing the retained pages.

Validation: all original case-study text fragments compared against the source using frequency counts; About and Contact bodies unchanged. All 14 pages pass nesting, single H1, unique ID, metadata, internal link and anchor checks. All five contribution filters, both project readers, native dialog Escape/focus return, keyboard radio selection, and 390px overflow checks passed. Image/report and two-column comparison rendering passed with isolated QA fixtures, not client content.

## SEO Decision Room
The lab/decision-room page now provides five fictional consulting scenarios, twenty investigation choices with strengths and limitations, and twenty-four expandable process steps. Each step includes a conditional next action. Choices and expanded steps persist during the page session when moving between scenarios. Previous/next controls and direct scenario navigation are available; the final CTA leads to the existing Contact page. No API, score, live findings or client results are used. Edit content/decision.json to maintain teaching content.

Validation: all twenty choices and twenty-four steps exercised in the browser; finish-screen focus, previous/next navigation, retained selections and keyboard activation checked. The mobile view at 390px had no horizontal overflow. Existing content-preservation and local-link checks passed.

## AI Citation Observatory
Four accessible tabs provide suggested buyer questions, manually entered observations, source-type counts and an editable findings notebook. Filters cover industry, platform and question text. Records support add/edit/delete, source URL categories, screenshot URL references, observation context and explicit genuine/demonstration types. No records are bundled. Only genuine filtered observations contribute to source counts; counts represent observations containing a source type, not unique domains or share of voice.

Data is held in browser localStorage under searchLabObservatory.v1, specific to the browser and origin. CSV export includes all records with their data type, sources and evidence URLs; notebook export is separate text. CSV escapes quotes/newlines and prefixes spreadsheet formula-like inputs. Screenshot files are not uploaded. Storage errors leave the entry form open. Use a stable served origin for ongoing research; local-file storage behaviour can vary by browser. Exports are backups for reading, not an implemented import/synchronisation workflow.

Browser checks: add/edit a demonstration record, add a source and screenshot reference, exclude demonstration data from counts, filter industry, search buyer questions, export CSV, save findings, reopen and verify persistence, delete test record, keyboard arrow tab navigation. At 390px the observation table scrolls inside its own container and the form fits the viewport. Test entries were removed. Existing case-study text and links remain validated. This is a local prototype; no public research or live integration is claimed.

## From Search to Customer
The search-journey page contains three fictional personas and six stages per persona. Content is maintained in content/journey.json. Each stage explains the customer's thinking, possible query, useful content, relevant search practices and measurement. Switching persona retains the stage for comparison. Desktop uses a connected horizontal route; mobile moves the detail panel directly beneath the selected step. Native radio controls, keyboard-operable stage buttons, current-step state, live announcements and previous/next controls are included. Illustrative labels and attribution limitations distinguish AI observations, visits, enquiries and customer outcomes. The CTA leads to the existing Contact page.

Validation: all eighteen stage views checked on desktop and at 390px; every mobile panel opened beneath its selected step without horizontal page overflow. Keyboard stage selection and previous/next controls checked. Final CTA opened the Contact page. Existing page structure, internal links and original case-study wording checks passed.

## Experiment Archive
Five proposed experiments are stored in content/experiments.json and rendered as semantic expandable notebook records. All six categories are filterable. No results, dates, sample sizes or evidence were invented. Status controls are explicitly browser-local working labels, separate from published source status. Local working statuses may be lost if browser storage is cleared.

To add an entry, copy content/experiment-template.json into the entries array, assign a unique slug and number, and fill all six sections. Set status to Planned, In Progress, Completed or Inconclusive. Set proposed to false only when actual work has begun. Use date as an ISO record-update date; sample_size and sample_unit describe the actual observed sample, not an arbitrary performance score. Keep null values when unknown. Record negative or inconclusive results as honestly as positive ones. Rebuild with build.py and package with work/package.py from the project root.

Evidence entries accept {"approved":true,"type":"image","url":"https://your-approved-image-url","alt":"Accurate image description","caption":"What this evidence demonstrates"}. Approved report links use type "report" and a title instead of an image. Unapproved evidence is omitted. Keep evidence accessible at a stable address; it is not uploaded automatically. Images open at full size in a separate browser tab. The public template download contains no client data.

Archive validation: six category filters, all five expanded records (thirty sections), all four local statuses and native keyboard expansion checked in the browser. Mobile width 390px showed no horizontal overflow. Renderer checks covered approved/unapproved evidence and optional date/sample rendering using unpublished test inputs. No fixture results or evidence were included in the site.

## Search Intelligence
The /journal/ index contains four editorial categories and six clearly labelled draft articles. Each article is a separate JSON file in content/articles/. Copy content/article-template.json into that directory, choose a unique slug and fill the introduction, sections, references, related article slugs and lab link. Build.py discovers article files automatically. The index is server-rendered HTML with a small category filter; articles and navigation do not need JavaScript. Reading time is calculated from the introduction and body at 220 words per minute. Four or more sections generate a linked table of contents.

Drafts display their author, draft revision date and “Publication date: not published”. They emit noindex,follow and Article JSON-LD with creativeWorkStatus Draft, omitting datePublished. To publish after editorial review, set status to published and supply an actual ISO published_at date. Keep updated_at accurate. The site configuration canonical_origin must be set to the verified production origin; it is currently blank, so no guessed canonical links or absolute schema URLs are emitted. When configured, canonical URLs and Article mainEntityOfPage/author URLs are generated automatically. No ratings or unsupported credentials are used.

Sources are stored by ID with title, verified https URL and checked date. Section source IDs produce contextual citations; references also appear at the end. Verify sources before adding them. The current technical references were checked on 2026-10-24 against Google Search Central and Screaming Frog documentation. The workflow draft is grounded in the preserved Outcraft account and does not claim efficiency measurements. The measurement draft is explicitly proposed analysis, not sourced client research.

Optional media entries use approved:true, url (https), alt and caption. No screenshots were supplied or fabricated. Related links must point to existing article slugs. Existing case studies remain unchanged.

Validation: category filtering, article navigation and TOC anchors tested in browser; article widths checked at 390px and 820px without horizontal overflow. All six pages checked for semantic structure, internal links, draft noindex, valid JSON-LD and omitted publication dates. A separate temporary build tested publication dates and canonical generation with a test origin; those test values are not in the delivered site.

## The Recovery Lab
Added at lab/recovery/index.html and linked from the lab directory. It preserves the existing portfolio and Exchange My Car wording. The educational tool makes no network audit requests and asks for no URL, credentials or sensitive documents. Wizard answers and checklist ticks remain in memory for the current page session.

Maintain reference data in content/recovery-updates.json (official dates, types, incident links, review date), recovery-policies.json (fourteen policy entries), recovery-diagnostics.json (eight evidence checks and seven symptom plans), and recovery-examples.json (fictional before/after pages, seven reserved .example backlink cases, five-phase roadmap). Timeline dates were checked on the official Google Search Status Dashboard on 2026-10-24: March spam 24–25 March, March core 27 March–8 April, May core 21 May–2 June, June spam 24–26 June, August spam 18–21 August, September spam 24 September–8 October. Dates use US/Pacific calendar boundaries; overlap is inclusive at day granularity and is explicitly not causal evidence. The snapshot is selected, not exhaustive or live.

The wizard requires a symptom, accepts an unknown date or valid date/range, and distinguishes report review from actual reported findings. A reported security issue takes priority, followed by a reported manual action; ordinary symptoms retain their own investigation plan. Evidence still needed and uncertainty are explicit even if every report is marked checked. The separate progressive disavow guide requires considerable problematic links plus an actual or credibly likely unnatural-links manual action before specialist consideration, and prioritises removal or qualification where possible. Unknown answers do not produce a disavow recommendation. No disavow file is generated.

The policy library includes official references and review dates, fictional examples and investigation/remediation caveats. Manual-action and security reviews remain separate. Reconsideration copy is a fictional training example, not a statement of work completed by Sibghat. Exchange My Car is linked without claiming a penalty or backlink causation. Content comparisons do not infer spam from AI authorship or low traffic; all five editorial decisions explain tradeoffs. Checklist export preserves current ticks; the blank text download works without JavaScript. Print styles isolate the checklist; no physical print job was sent during verification.

Browser validation: all seven symptom routes; security/manual override precedence; required symptom and invalid date ranges; matching September rollout and no-overlap state; four spam/two core filters; all nine before/after comparison modes and fifteen tradeoff choices; seven backlink filters/reviews; disavow threshold, unknown and removal-first branches; all fourteen policy expansions; five roadmap phases; security guide expansion; checklist export. Mobile 390px has no page overflow, the report scrolls in its own container, and keyboard wizard controls maintain result focus. Existing structure, metadata, local links and case-study preservation checks passed. Official sources were checked; the site performs no live penalty detection or promised recovery.

## B2B and B2C positioning update
Homepage hero, introduction, experience strip and secondary contact CTA now use the supplied positioning. Finance and automotive are presented as key industries; B2B and B2C describe business models and customer journeys. The homepage includes concise finance, automotive and service-audience context, and its discovery preview now uses a UK car-selling question. About preserves roles, dates, location and tools while updating the introduction and experience description.

The Evidence Room adds Automotive / B2C and Branding & Growth Marketing / B2B & B2C context without changing original case-study text. No finance case study or outcome was invented. Demonstration labels and the business-service journey replace generic SaaS positioning; stable internal scenario IDs remain unchanged to preserve interactions. Observatory research context labels are updated. Legacy browser records keep their original stored category and export values; filtering and presentation map the old category to B2B services, and editing retains its legacy value unless the user changes it. User-entered evidence and notes are not rewritten.

Validation: original case-study text remains preserved; About changes explicitly checked; public HTML scanned for stale SaaS positioning. Desktop 1366×768 and mobile 390px hero had no horizontal overflow. Experience figures and both CTAs remain present, automotive AI preview toggles, primary CTA opens Evidence Room, secondary CTA opens Contact, B2B simulator selection works and About positioning is visible. Existing module data/link checks passed.
