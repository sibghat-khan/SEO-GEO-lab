from pathlib import Path
from html import escape as e
from datetime import date
from urllib.parse import urlsplit
import json,math,re
root=Path(__file__).parent
publication=json.loads((root/'content/publication.json').read_text())
articles=[json.loads(p.read_text()) for p in sorted((root/'content/articles').glob('*.json'))]
by_slug={a['slug']:a for a in articles}
assert len(by_slug)==len(articles)
def reading(a):
 text=a['introduction']+' '+ ' '.join(' '.join(s['paragraphs']) for s in a['sections'])
 return max(1,math.ceil(len(text.split())/220))
def validate(a):
 assert re.fullmatch('[a-z0-9-]+',a['slug'])
 assert a['status'] in ['draft','published'] and a['category'] in publication['categories']
 if a['status']=='published':assert a['published_at'];date.fromisoformat(a['published_at'])
 date.fromisoformat(a['updated_at'])
 assert len({s['id'] for s in a['sections']})==len(a['sections'])
 for s in a['sections']:
  assert re.fullmatch('[a-z0-9-]+',s['id']) and set(s['sources'])<=set(a['sources'])
 for source in a['sources'].values():assert urlsplit(source['url']).scheme=='https' and source['checked']
 assert all(slug in by_slug and slug!=a['slug'] for slug in a['related'])
for a in articles:
 validate(a);path=f'journal/{a["slug"]}/index.html';draft=a['status']=='draft'
 meta=f'<a href="{rel("about/index.html",path)}">{e(a["author"])}</a><span>{reading(a)} min read</span>'
 meta+=('<span>Publication date: not published</span>' if draft else f'<span>Published <time datetime="{a["published_at"]}">{a["published_at"]}</time></span>')
 meta+=f'<span>{"Draft revised" if draft else "Updated"} <time datetime="{a["updated_at"]}">{a["updated_at"]}</time></span>'
 toc='<nav class="article-toc" aria-label="In this article"><strong>In this article</strong><ol>'+''.join(f'<li><a href="#{s["id"]}">{e(s["heading"])}</a></li>' for s in a['sections'])+'</ol></nav>' if len(a['sections'])>=4 else ''
 sections=''
 for s in a['sections']:
  sections+=f'<section id="{s["id"]}"><h2>{e(s["heading"])}</h2>'+''.join('<p>'+e(p)+'</p>' for p in s['paragraphs'])
  if s['sources']:sections+='<p class="article-source-inline">Reference: '+', '.join(f'<a href="{e(a["sources"][k]["url"],quote=True)}">{e(a["sources"][k]["title"])}</a>' for k in s['sources'])+'.</p>'
  sections+='</section>'
 for media in a['media']:
  if media.get('approved') is not True:continue
  assert urlsplit(media['url']).scheme=='https'
  sections+=f'<figure><img src="{e(media["url"],quote=True)}" alt="{e(media["alt"],quote=True)}" loading="lazy"><figcaption>{e(media["caption"])}</figcaption></figure>'
 references='<section class="article-references"><h2>Source references</h2>'
 references+=('<ul>'+''.join(f'<li><a href="{e(s["url"],quote=True)}">{e(s["title"])}</a><small>Checked {s["checked"]}</small></li>' for s in a['sources'].values())+'</ul>') if a['sources'] else '<p>This draft presents a proposed measurement approach. It contains no external research findings or numerical results.</p>'
 references+='</section>'
 related='<aside class="article-related"><p class="eyebrow">CONTINUE READING</p><h2>Related ideas</h2>'+''.join(f'<a href="../{slug}/index.html"><small>{"Draft" if by_slug[slug]["status"]=="draft" else "Article"} / {e(by_slug[slug]["category"])}</small><span>{e(by_slug[slug]["title"])}</span></a>' for slug in a['related'])+'</aside>'
 body=f'<div class="breadcrumbs"><a href="../index.html">Search Intelligence</a> / {e(a["category"])}</div><article class="intelligence-article"><header class="article-header"><p class="eyebrow">{e(a["category"].upper())} / {"EDITORIAL DRAFT" if draft else "ANALYSIS"}</p><h1>{e(a["title"])}</h1><p class="article-intro">{e(a["introduction"])}</p><div class="article-byline">{meta}</div></header>'
 if draft:body+='<aside class="article-draft"><strong>Draft · not published</strong><p>Working editorial copy for review. No original research findings or unprovided client outcomes are claimed.</p></aside>'
 body+=f'<div class="article-layout">{toc}<div class="article-prose">{sections}{references}<aside class="article-lab"><p class="eyebrow">EXPLORE THE THINKING</p><a href="{rel(a["lab_link"]["path"],path)}">{e(a["lab_link"]["label"])} ↗</a></aside></div></div></article>{related}<section class="simple-contact"><h2>Bring a search question.</h2><a class="button" href="{rel("contact/index.html",path)}">Discuss your search challenge ↗</a></section>'
 shell(path,a['title'],a['description'],body,draft)
 schema={'@context':'https://schema.org','@type':'Article','headline':a['title'],'description':a['description'],'author':{'@type':'Person','name':a['author']},'articleSection':a['category'],'inLanguage':'en','dateModified':a['updated_at'],'creativeWorkStatus':'Draft' if draft else 'Published'}
 if not draft:schema['datePublished']=a['published_at']
 origin=config.get('canonical_origin','').rstrip('/')
 if origin:
  schema['url']=origin+'/journal/'+a['slug']+'/'
  schema['mainEntityOfPage']={'@type':'WebPage','@id':schema['url']}
  schema['author']['url']=origin+'/about/'
 p=root/'dist'/path;s=p.read_text();s=s.replace('</head>','<script type="application/ld+json">'+json.dumps(schema).replace('<','\\u003c')+'</script></head>');p.write_text(s)
rows=''
for i,a in enumerate(articles,1):
 rows+=f'<article class="intelligence-row" data-category="{e(a["category"],quote=True)}"><span class="intelligence-number">{i:02}</span><div><p class="eyebrow">{e(a["category"])} / {"DRAFT" if a["status"]=="draft" else "ARTICLE"}</p><h2><a href="{a["slug"]}/index.html">{e(a["title"])}</a></h2><p>{e(a["description"])}</p><small>By {e(a["author"])} · {reading(a)} min read · '+('Not published' if a['status']=='draft' else a['published_at'])+'</small></div></article>'
body='<section class="pagehero intelligence-masthead"><p class="eyebrow">THE SEARCH LAB / AN EDITORIAL NOTEBOOK</p><h1>Search <em>Intelligence</em></h1><p>Research, observations, and ideas on how discovery is changing.</p></section><div class="intelligence-intro"><p>Questions about how B2B and B2C businesses are discovered, with practical perspectives from finance, automotive and digital services.</p><p>The first six articles are editorial drafts. They combine practical analysis with checked references; they do not present invented research results.</p></div><section class="intelligence-desk"><label for="intelligence-category">Browse the publication</label><select id="intelligence-category"><option value="">All categories</option>'+''.join(f'<option>{e(c)}</option>' for c in publication['categories'])+'</select><p id="intelligence-count" role="status">'+str(len(articles))+' articles</p></section><div class="intelligence-index">'+rows+'</div><aside class="intelligence-sections"><h2>Four editorial perspectives.</h2><dl>'+''.join(f'<div><dt>{e(k)}</dt><dd>{e(v)}</dd></div>' for k,v in publication['categories'].items())+'</dl></aside>'
shell('journal/index.html','Search Intelligence','Research, observations and practical ideas on SEO, AI discovery, organic growth and measurement, by Sibghat Khan.',body)
