from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import re
root=Path(__file__).parent
class Page(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.links=[];self.stack=[];self.h1=0
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if t=='h1':self.h1+=1
  if 'id' in a:self.ids.append(a['id'])
  for k in ('href','src'):
   if k in a:self.links.append(a[k])
  if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.stack.append(t)
 def handle_endtag(self,t):assert self.stack and self.stack.pop()==t, t
pages={}
for f in (root/'dist').rglob('*.html'):
 p=Page();s=f.read_text();p.feed(s);assert not p.stack,f;assert p.h1==1,f;assert len(p.ids)==len(set(p.ids)),f
 assert '<title>' in s and 'name="description"' in s
 pages[f.resolve()]=p
for f,p in pages.items():
 for link in p.links:
  u=urlsplit(link)
  if u.scheme or u.netloc:continue
  target=(f.parent/unquote(u.path)).resolve() if u.path else f
  assert target.exists(),(f,link)
  if u.fragment:assert u.fragment in pages[target].ids,(f,link)
for f in (root/'original').rglob('*.html'):
 if f in [root/'original/index.html',root/'original/work/index.html']:continue
 original=re.search(r'<main[^>]*>(.*?)</main>',f.read_text(),re.S).group(1)
 new=re.search(r'<main[^>]*>(.*?)</main>',(root/'dist'/f.relative_to(root/'original')).read_text(),re.S).group(1)
 if f.parent.name in ['exchange-my-car','outcraft']:
  # Layout changes are authorised; every original text fragment remains verbatim.
  class Texts(HTMLParser):
   def __init__(self):super().__init__();self.items=[]
   def handle_data(self,data):
    if data.strip():self.items.append(data.strip())
  old=Texts();old.feed(original);fresh=Texts();fresh.feed(new)
  from collections import Counter
  assert not (Counter(old.items)-Counter(fresh.items)),(f,Counter(old.items)-Counter(fresh.items))
 elif f.parent.name=='about':
  assert 'SEO, GEO, AEO, and Growth Strategist' in new and 'B2B and B2C' in new
  assert 'SaaS' not in new
  assert '2022–present' in new and '1 year 7 months' in new and 'Screaming Frog' in new
 else:assert original==new,f
print(f'PASS: {len(pages)} pages; HTML nesting, unique IDs, titles, descriptions, local links and anchors. Original case-study wording preserved; Contact unchanged; authorised About positioning verified.')
import json
scenarios=json.loads((root/'content/simulator.json').read_text())
for industry in scenarios:
 assert len(industry['questions'])>=2
 for q in industry['questions']:
  ids={s['id'] for s in q['sources']}
  assert set(re.findall(r'\[([A-Z])\]',q['answer']+' '+q['brand'])) <= ids,q['id']
  assert len(ids)==len(q['sources']),q['id']
  assert all('.example/' in s['url'] and s['excerpt'] for s in q['sources']),q['id']
print('PASS: all six scenarios have matching fictional source references and supporting excerpts.')

# Intentional sample defects live only inside the isolated preview document.
import runpy
xray=runpy.run_path(str(root/'xray_build.py'))
notes=json.loads((root/'content/xray-notes.json').read_text())
assert len(notes)==10 and sum(n['issue'] for n in notes)==6
for state,html in xray['pages'].items():
 p=Page();p.feed(html);assert not p.stack
 assert p.h1==(2 if state=='before' else 1),state
 assert 'name="robots" content="noindex"' in html
 for href in p.links:
  if href.startswith('#'):assert href[1:] in p.ids,href
 expected='https://relaydesk.example/'+('payroll' if state=='before' else 'remote-device-management')
 assert 'rel="canonical" href="'+expected+'"' in html
 for note in notes:assert 'data-inspect="'+note['id']+'"' in html,note['id']
print('PASS: ten X-Ray inspection points, exactly six deliberate issues, before/after heading and canonical changes, sample anchors, and retained noindex.')
# Workshop coverage: every scenario offers substantive alternatives and a complete process.
decisions=json.loads((root/'content/decision.json').read_text())
assert len(decisions)==5 and len({s['id'] for s in decisions})==5
for scenario in decisions:
 assert len(scenario['choices']) in (3,4) and len(scenario['evidence'])>=2
 assert all(all(c[k].strip() for k in ('title','strength','limit')) for c in scenario['choices'])
 assert all(all(s[k].strip() for k in ('title','check','branch')) for s in scenario['steps'])
 assert scenario['takeaway'].strip()
print('PASS: five Decision Room scenarios, twenty explained choices and twenty-four investigation steps.')
journeys=json.loads((root/'content/journey.json').read_text())
assert [p['name'] for p in journeys]==['B2B services','Finance','Automotive']
for persona in journeys:
 assert [s['name'] for s in persona['stages']]==['Problem','Discovery','Research','Evaluation','Conversion','Measurement']
 for stage in persona['stages']:
  assert all(stage[k].strip() for k in ('thinking','query','approach','measurement'))
  assert len(stage['content'])>=2
print('PASS: three customer personas, six complete stages each; content, approach and measurement present.')
archive=json.loads((root/'content/experiments.json').read_text())
assert len({x['id'] for x in archive['entries']})==len(archive['entries'])
for x in archive['entries']:
 assert x['status'] in ['Planned','In Progress','Completed','Inconclusive']
 assert all(x[k] for k in ['question','hypothesis','method','evidence_text','outcome','learning'])
 assert set(x['categories'])<=set(archive['categories'])
 if x['proposed']:assert x['status']=='Planned' and x['sample_size'] is None and not x['evidence']
print('PASS: archive proposals have complete sections, valid categories and no invented observations.')
for source in (root/'content/articles').glob('*.json'):
 a=json.loads(source.read_text());html=(root/'dist/journal'/a['slug']/'index.html').read_text()
 schema=json.loads(re.search(r'<script type="application/ld\+json">(.*?)</script>',html,re.S).group(1))
 assert schema['@type']=='Article' and schema['headline']==a['title']
 assert schema['author']['name']=='Sibghat Khan'
 if a['status']=='draft':
  assert 'noindex,follow' in html and 'datePublished' not in schema and 'Draft · not published' in html
 assert all('href="#'+s['id']+'"' in html for s in a['sections'])
 assert all(s['url'] in html for s in a['sources'].values())
print('PASS: six article drafts, valid JSON-LD, unpublished dates omitted, TOC destinations and checked source references.')
# Recovery reference coverage and evidence boundaries.
updates=json.loads((root/'content/recovery-updates.json').read_text())['updates']
assert len([u for u in updates if u['type']=='Spam'])==4
for u in updates:
 assert u['start']<=u['end'] and u['source'].startswith('https://status.search.google.com/incidents/') and u['reviewed']=='2026-10-24'
assert next(u for u in updates if u['name']=='September 2026 spam update')['end']=='2026-10-08'
policies=json.loads((root/'content/recovery-policies.json').read_text())
assert len(policies)==14 and len({p['id'] for p in policies})==14
assert all(all(p[k] for k in ['meaning','example','signs','investigation','remediation','misconception','source','reviewed']) for p in policies)
examples=json.loads((root/'content/recovery-examples.json').read_text())
assert len(examples['comparisons'])==3 and len(examples['backlinks'])==7 and len(examples['roadmap'])==5
for c in examples['comparisons']:
 assert set(c['choices'])=={'keep','consolidate','remove','noindex','investigate'} and c['before'] and c['after']
for link in examples['backlinks']:
 assert urlsplit(link['url']).hostname.endswith('.example')
plans=json.loads((root/'content/recovery-diagnostics.json').read_text())
assert len(plans['plans'])==7 and len(plans['reports'])==8
assert all(set(p['priority'])<=set(r['id'] for r in plans['reports']) for p in plans['plans'].values())
assert (root/'dist/assets/seo-recovery-checklist.txt').exists()
print('PASS: Recovery Lab timeline sources, fourteen policy records, seven symptom plans, three comparisons, seven fictional backlinks, five phases and checklist.')
# Public positioning uses industries separately from customer/business models.
for page in (root/'dist').rglob('*.html'):
 assert not re.search(r'\bSaaS\b',page.read_text()),page
hero=(root/'dist/index.html').read_text()
assert 'Business and consumer markets' in hero and 'International market experience' in hero
assert 'Finance &amp; Automotive' in hero and 'href="contact/index.html">Let\'s Talk' in hero
print('PASS: updated B2B/B2C positioning, experience strip and contact CTA; no public HTML SaaS positioning.')
