from pathlib import Path
from html import escape,unescape
import json,re,shutil
root=Path(__file__).parent
if (root/'content/evidence-media').exists():
 shutil.copytree(root/'content/evidence-media',root/'dist/assets/evidence',dirs_exist_ok=True)
projects=json.loads((root/'content/evidence-projects.json').read_text())
filters=['All contributions','Technical SEO','Content Strategy','GEO / AEO','Growth Marketing','Analytics']
records={};pairs={}
def text(s):return unescape(re.sub('<[^>]+>','',s))
def controls():return '<fieldset class="ev-filters"><legend>Explore My Contribution</legend>'+''.join('<label><input type="radio" name="contribution" value="'+escape(f,quote=True)+'"'+(' checked' if i==0 else '')+'><span>'+escape(f)+'</span></label>' for i,f in enumerate(filters))+'</fieldset>'
def section(n,title,body):return f'<section id="chapter-{n}" class="ev-chapter"><h2><span>{n:02} /</span> {title}</h2>{body}</section>'
def lower(s):return s.replace('<section>','<div class="ev-original">').replace('</section>','</div>').replace('<h2>','<h3>').replace('</h2>','</h3>')
def reader():return '<dialog class="ev-dialog" id="evidence-dialog" aria-labelledby="evidence-title"><div class="ev-dialog-top"><p id="evidence-kind" class="eyebrow"></p><button type="button" data-close-evidence>Close ×</button></div><h2 id="evidence-title"></h2><p id="evidence-context"></p><div id="evidence-media"></div><p id="evidence-source"></p><p id="evidence-limit"></p></dialog>'
def entry_button(id,title,label):return '<button type="button" class="ev-record" data-evidence="'+escape(id,quote=True)+'"><span class="eyebrow">'+escape(label)+'</span><span>'+escape(title)+' <span aria-hidden="true">↗</span></span></button>'
def optional_evidence(p):
 markup=''
 for item in p['evidence']:
  if not item.get('approved'):continue
  assert item['kind'] in ['image','report'] and item.get('source') and item.get('context') and item.get('limit')
  id=p['slug']+'-'+item['id'];records[id]=item
  if item['kind']=='image':
   assert item.get('alt') and (root/'dist'/item['src']).is_file(),item
  else:assert item.get('text')
  markup+=entry_button(id,item['title'],'Approved project material')
 for pair in p['comparisons']:
  if not pair.get('approved'):continue
  assert pair.get('context') and pair.get('source') and pair['kind'] in ['image','text']
  for k in ['before','after']:
   assert pair[k].get('label')
   if pair['kind']=='image':assert (root/'dist'/pair[k]['src']).is_file() and pair[k].get('alt')
   else:assert pair[k].get('text')
  id=p['slug']+'-'+pair['id'];pairs[id]=pair
  markup+='<button type="button" class="ev-record" data-comparison="'+escape(id)+'"><span class="eyebrow">Before and After</span><span>'+escape(pair['title'])+' ↗</span></button>'
 return markup
for p in projects:
 source=(root/'original/work'/p['slug']/'index.html').read_text()
 main=re.search(r'<main[^>]*>(.*?)</main>',source,re.S).group(1)
 article=re.search(r'<article class="compact-case">(.*?)</article>',main,re.S).group(1)
 sections=re.findall(r'<section>.*?</section>',article,re.S)
 details=re.search(r'<details>.*?</details>',article,re.S).group(0)
 contribution=re.findall(r'<li>(.*?)</li>',sections[1],re.S)
 assert len(contribution)==len(p['contributionTags'])
 p['contributions']=[{'text':text(c),'tags':tags} for c,tags in zip(contribution,p['contributionTags'])]
 p['tags']=sorted(set(t for c in p['contributions'] for t in c['tags']))
 p['summary']=re.search(r'<div class="pagehero">.*?<p>(.*?)</p>',main,re.S).group(1)
 if p['slug']=='exchange-my-car':
  account=text(re.search(r'<p>(.*?)</p>',sections[2],re.S).group(1))
  investigation='<p>'+re.findall(r'<p>(.*?)</p>',details,re.S)[0]+'</p><p class="ev-editor-note">The contribution and scope sections below retain the original account of the review and changes.</p>'
  situation=lower(sections[0]);work=lower(sections[1]+sections[2]);outcome=lower(sections[3]);lessons=details
 else:
  account='\n\n'.join(text(v) for v in re.findall(r'<p>(.*?)</p>',sections[2],re.S))
  situation=lower(sections[0]);investigation=lower(sections[2]);work=lower(sections[1]);outcome=lower(sections[3]);lessons=details+'<p class="ev-reflection">I have learned to spend more time understanding the business and its audience before recommending channels, keywords, or campaigns.</p>'
 account_id=p['slug']+'-account'
 records[account_id]={'kind':'account','title':p['name']+' — project account','text':account,'source':'Source: existing case-study text, supplied by Sibghat Khan.','context':'This passage describes the scope and approach reported in the project account.','limit':'This is an author-supplied account, not an independent implementation record or verified performance report.'}
 evidence='<p class="ev-evidence-note">The available material is the project account below. No verified screenshots, audit records, or reporting exports are published with this case study.</p>'+entry_button(account_id,'Read the project account','Author-supplied account')+optional_evidence(p)
 if not any(x.get('approved') for x in p['comparisons']):evidence+='<p class="ev-editor-note">A before-and-after comparison is not published because verified paired versions have not been supplied.</p>'
 chapter_names=['The Situation','The Investigation','The Work','The Evidence','The Outcome','What I Learned']
 navigation='<nav class="ev-chapter-nav" aria-label="Case-study chapters">'+''.join(f'<a href="#chapter-{i}"><span>{i:02}</span> {name}</a>' for i,name in enumerate(chapter_names,1))+'</nav>'
 replacement=navigation+'<article class="ev-case">'+''.join(section(i,name,body) for i,(name,body) in enumerate(zip(chapter_names,[situation,investigation,work,evidence,outcome,lessons]),1))+'</article>'
 revised=main.replace('<article class="compact-case">'+article+'</article>',replacement)
 revised=revised.replace('</h1>', '</h1><p class="ev-model-context">'+escape(p['industry'])+'</p>',1)
 revised=revised.replace('<div class="pagehero">','<div class="pagehero ev-case-hero">',1)
 shell('work/'+p['slug']+'/index.html',p['name']+' | The Evidence Room',text(p['summary']),revised+reader())

def card(p,home=False):
 href=('work/' if home else '')+p['slug']+'/index.html'
 tags=escape(json.dumps(p['tags']),quote=True)
 thumbnail=next((e for e in p['evidence'] if e.get('approved') and e['kind']=='image' and e.get('thumbnail')),None)
 visual=''
 if thumbnail:
  src=('../' if not home else '')+thumbnail['src']
  visual='<figure class="ev-project-image"><img src="'+escape(src,quote=True)+'" alt="'+escape(thumbnail['alt'],quote=True)+'" loading="lazy"><figcaption>'+escape(thumbnail.get('caption','Project screenshot'))+'</figcaption></figure>'
 return '<article class="ev-project" data-project="'+p['slug']+'" data-tags="'+tags+'"><div class="ev-project-identity"><p class="eyebrow">'+escape(p['industry'])+'</p><h2>'+escape(p['name'])+'</h2><p class="ev-role">'+escape(p['role'])+'<span>'+escape(p['period'])+'</span></p>'+visual+'</div><div class="ev-project-story"><p class="ev-label">The business challenge</p><p class="ev-challenge">'+escape(p['challenge'])+'</p><p class="ev-label">Areas of contribution</p><ul class="ev-areas">'+''.join('<li>'+escape(t)+'</li>' for t in p['areas'])+'</ul><div class="ev-matches" hidden></div><a class="textlink" href="'+href+'">Explore the Case Study ↗</a></div></article>'
archive='<section class="pagehero ev-room-hero"><p class="eyebrow">SELECTED PROJECT ACCOUNTS</p><h1>The Evidence Room</h1><p>Real projects. Real problems. Practical solutions.</p></section><div class="ev-archive">'+controls()+'<p class="ev-filter-status" role="status" aria-live="polite">Showing 2 projects · all contributions</p><div class="ev-projects">'+''.join(card(p) for p in projects)+'</div><p class="ev-empty" hidden>No published project contributions match this filter.</p></div><section class="ev-archive-note"><h2>Work first. Claims supported.</h2><p>These accounts distinguish personal contribution from wider team work. Where measurement sources or implementation records are unavailable, the case study says so.</p><a class="textlink" href="../contact/index.html">Discuss a similar challenge ↗</a></section>'
shell('work/index.html','The Evidence Room','Explore Sibghat Khan’s Exchange My Car and Outcraft project accounts, personal contributions, evidence limitations and practical lessons.',archive)
# Replace only the selected-work preview, retaining the rest of the homepage.
homepath=root/'dist/index.html';home=homepath.read_text()
new_preview='<section class="selected ev-home"><div class="sectionhead"><div><p class="eyebrow">THE EVIDENCE ROOM</p><h2>Real projects.<br><em>Practical solutions.</em></h2></div><a class="textlink" href="work/index.html">Explore My Contribution →</a></div>'+''.join(card(p,True) for p in projects)+'</section>'
home=re.sub(r'<section class="selected">.*?</section>',lambda m:new_preview,home,count=1,flags=re.S);homepath.write_text(home)
(root/'dist/assets/evidence-data.js').write_text('window.evidenceProjects='+json.dumps(projects)+';\nwindow.evidenceRecords='+json.dumps(records)+';\nwindow.evidenceComparisons='+json.dumps(pairs)+';')
