from pathlib import Path
import re,json,os,shutil
from html import escape
root=Path(__file__).parent
out=root/'dist';out.mkdir(exist_ok=True)
modules=json.loads((root/'content/experiences.json').read_text())
config=json.loads((root/'content/site.json').read_text())
nav=[('index.html','Home'),('lab/index.html','The Lab'),('work/index.html','Evidence Room'),('journal/index.html','Search Intelligence'),('about/index.html','About'),('contact/index.html','Let’s talk')]
def rel(target,path):return os.path.relpath(out/target,(out/path).parent)
def shell(path,title,desc,body,preview=False):
 links=''.join(f'<a href="{rel(p,path)}"'+(' aria-current="page"' if p==path or p=='journal/index.html' and path.startswith('journal/') or p=='lab/index.html' and path.startswith('lab/') or p=='work/index.html' and path.startswith('work/') else '')+f'>{l}</a>' for p,l in nav)
 header=f'<a class="skip" href="#main">Skip to content</a><header class="site-header"><div class="wrap header-inner"><a class="lab-brand" href="{rel("index.html",path)}" aria-label="The Search Lab home"><span class="brand-mark" aria-hidden="true">S<span>↗</span></span><span>THE SEARCH LAB<small>BY SIBGHAT KHAN</small></span></a><button class="menu-toggle" aria-expanded="false" aria-controls="main-nav" hidden>Menu</button><nav id="main-nav" aria-label="Main navigation">{links}</nav></div></header>'
 footer=f'<footer class="wrap lab-footer"><div><strong>THE SEARCH LAB</strong><p>By Sibghat Khan — SEO, GEO &amp; Growth Strategist</p></div><div><a href="{rel("lab/archive/index.html",path)}">Experiment Archive</a><a href="{rel("contact/index.html",path)}">Contact ↗</a><small>© 2026 Sibghat Khan · Islamabad, Pakistan</small></div></footer>'
 extra=''
 if path=='lab/discovery/index.html':
  extra=''.join('<script src="'+rel('assets/'+f,path)+'" defer></script>' for f in ['simulator-data.js','simulator.js'])
 if path=='lab/recovery/index.html':
  extra=''.join('<script src="'+rel('assets/'+f,path)+'" defer></script>' for f in ['recovery-data.js','recovery.js'])
 if path=='journal/index.html':
  extra='<script src="'+rel('assets/journal.js',path)+'" defer></script>'
 if path=='lab/archive/index.html':
  extra='<script src="'+rel('assets/archive.js',path)+'" defer></script>'
 if path=='lab/search-journey/index.html':
  extra=''.join('<script src="'+rel('assets/'+f,path)+'" defer></script>' for f in ['journey-data.js','journey.js'])
 if path=='lab/citation-observatory/index.html':
  extra='<script src="'+rel('assets/observatory.js',path)+'?v=3" defer></script>'
 if path=='lab/decision-room/index.html':
  extra=''.join('<script src="'+rel('assets/'+f,path)+'" defer></script>' for f in ['decision-data.js','decision.js'])
 if path=='lab/seo-x-ray/index.html':
  extra=''.join('<script src="'+rel('assets/'+f,path)+'" defer></script>' for f in ['xray-data.js','xray.js'])
 if path.startswith('work/'):
  extra=''.join('<script src="'+rel('assets/'+f,path)+'" defer></script>' for f in ['evidence-data.js','evidence.js'])
 schema=json.dumps({'@context':'https://schema.org','@type':'Person','name':'Sibghat Khan','jobTitle':'SEO, GEO, AEO, and Growth Strategist'}) if path=='about/index.html' else ''
 html=f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{escape(title)} — The Search Lab</title><meta name="description" content="{escape(desc,quote=True)}"><meta name="theme-color" content="#173E32">'+ ('<meta name="robots" content="noindex,follow">' if preview else '')+f'<link rel="stylesheet" href="{rel("assets/legacy.css",path)}"><link rel="stylesheet" href="{rel("assets/system.css",path)}"><script src="{rel("assets/navigation.js",path)}" defer></script>'+ (f'<script type="application/ld+json">{schema}</script>' if schema else '')+extra+f'</head><body>{header}<main id="main" class="wrap">{body}</main>{footer}</body></html>'
 origin=config.get('canonical_origin', '').rstrip('/')
 if origin:
  canonical=origin+'/'+('' if path=='index.html' else path.replace('index.html',''))
  html=html.replace('</head>', '<link rel="canonical" href="'+escape(canonical,quote=True)+'"></head>')
  image=origin+'/assets/search-lab-social.jpg'
  social={'og:type':'website','og:site_name':'The Search Lab','og:title':title+' — The Search Lab','og:description':desc,'og:url':canonical,'og:image':image,'og:image:secure_url':image,'og:image:type':'image/jpeg','og:image:width':'1200','og:image:height':'627','og:image:alt':'The Search Lab by Sibghat Khan. Helping businesses get found. And turn visibility into growth. SEO, GEO and organic growth.'}
  tags=''.join(f'<meta property="{key}" content="{escape(value,quote=True)}">' for key,value in social.items())
  tags+=f'<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{escape(title,quote=True)}"><meta name="twitter:description" content="{escape(desc,quote=True)}"><meta name="twitter:image" content="{image}">'
  html=html.replace('</head>',tags+'</head>')
 p=out/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(html)
# Preserve every existing inner page body and its local destinations.
css=[]
for p in (root/'original').rglob('*.html'):
 s=p.read_text();css+=re.findall(r'<style>(.*?)</style>',s,re.S)
 path=str(p.relative_to(root/'original'))
 if path=='index.html':continue
 body=re.search(r'<main[^>]*>(.*?)</main>',s,re.S).group(1)
 if path=='about/index.html':
  body=body.replace('SEO and content strategist based in Islamabad, Pakistan.','SEO, GEO, AEO, and Growth Strategist based in Islamabad, Pakistan, helping B2B and B2C businesses improve their digital visibility.')
  body=body.replace('5+ years across content strategy and marketing leadership, with experience in automotive, finance, and SaaS across UK and US markets.','5+ years of experience in content strategy and marketing leadership across B2B and B2C businesses in finance, automotive, branding and digital services, primarily targeting UK and US markets.')
  body=body.replace('<section><h2>How I work</h2>','<section><h2>Industry perspective</h2><p>My finance work spans financial services content strategy, SEO, GEO and AEO, with attention to accuracy, credible sourcing and clear product education. In automotive, my work connects car-selling and valuation questions with useful content, commercial pages and technical SEO.</p><p>Across B2B and B2C services, I consider who is making the decision, what information they need and how search visibility connects with qualified enquiries. I distinguish industry experience from verified project outcomes.</p></section><section><h2>How I work</h2>')
 title=re.search(r'<title>(.*?)</title>',s).group(1).replace(' — Sibghat Khan','')
 desc=re.search(r'<meta name="description" content="([^"]*)',s).group(1)
 if path=='about/index.html':desc='Sibghat Khan is an SEO, GEO, AEO, and Growth Strategist with B2B and B2C experience in finance, automotive, branding and digital services across UK and US markets.'
 shell(path,title,desc,body)
assets=out/'assets';assets.mkdir(exist_ok=True)
shutil.copy(root/'content/search-lab-social.jpg',assets/'search-lab-social.jpg')
assets.joinpath('legacy.css').write_text('\n'.join(dict.fromkeys(css)))
home=(root/'original/index.html').read_text()
selected=re.search(r'<section class="selected">.*?</section>',home,re.S).group(0)
services=re.search(r'<section class="simple-services">.*?</section>',home,re.S).group(0)
hero=(root/'content/hero.html').read_text()
preview='''<section class="lab-preview"><div class="sectionhead"><div><p class="eyebrow">A SPACE TO EXAMINE SEARCH</p><h2>Inside the lab.</h2></div><p>Explore the questions behind the work. Interactive experiences are being developed in stages.</p></div><a class="feature-row" href="lab/discovery/index.html"><span class="index">01</span><div><h3>The Discovery Simulator</h3><p>One question. Two different search experiences.</p></div><span class="row-status">Explore <span aria-hidden="true">↗</span></span></a><a class="feature-row" href="lab/seo-x-ray/index.html"><span class="index">02</span><div><h3>SEO X-Ray</h3><p>Look beneath the page, layer by layer.</p></div><span class="row-status">Explore <span aria-hidden="true">↗</span></span></a><a class="textlink all-lab" href="lab/index.html">View the lab directory →</a></section>'''
contact='<section class="simple-contact"><div><p class="eyebrow">LET’S START WITH YOUR CHALLENGE</p><h2>What should search<br>do for your business?</h2></div><a class="button" href="contact/index.html">Let’s talk ↗</a></section>'
shell('index.html','Sibghat Khan | SEO, GEO & Growth Strategist','Explore Sibghat Khan’s SEO, GEO, AEO and growth work for B2B and B2C businesses, with experience in finance and automotive across UK and US markets.',hero+(root/'content/positioning.html').read_text()+selected+preview+services+contact)
rows=''.join(f'<a class="feature-row" href="{slug}/index.html"><span class="index">{i:02}</span><div><h2>{name}</h2><p>{tag}</p></div><span class="row-status">{"Explore ↗" if slug in ("discovery","seo-x-ray","decision-room","citation-observatory","search-journey","recovery") else "Preview ↗"}</span></a>' for i,(slug,name,tag,desc) in enumerate(modules,1))
shell('lab/index.html','The Lab','A directory of planned search demonstrations, decision exercises and experiments.','<section class="pagehero"><p class="eyebrow">THE LAB DIRECTORY</p><h1>Make the thinking<br><em>visible.</em></h1><p>Explore search experiences, examine an audit, work through a decision, follow a customer journey and document AI visibility.</p></section><div class="directory">'+rows+'</div><section class="simple-contact"><h2>Questions worth testing.</h2><a class="textlink" href="archive/index.html">Experiment Archive →</a></section>')
for slug,name,tag,desc in modules:
 if slug=='recovery':continue
 if slug=='search-journey':
  shell('lab/search-journey/index.html','From Search to Customer','Explore three illustrative customer journeys from problem and discovery to enquiry and measurement, connecting useful content with SEO, GEO and AEO.',(root/'content/journey.html').read_text())
  continue
 if slug=='citation-observatory':
  shell('lab/citation-observatory/index.html','AI Citation Observatory','A local research workspace for recording AI brand mentions, website citations, sources and evidence, with transparent sample limitations.',(root/'content/observatory.html').read_text())
  continue
 if slug=='decision-room':
  shell('lab/decision-room/index.html','The SEO Decision Room','Explore five fictional SEO and AI-search challenges, compare investigation choices and build an evidence-led approach.',(root/'content/decision.html').read_text())
  continue
 if slug=='seo-x-ray':
  shell('lab/seo-x-ray/index.html','SEO X-Ray','Inspect a fictional B2B services landing page, compare six deliberate SEO issues with their corrections, and explore ten audit checkpoints.',(root/'content/xray.html').read_text())
  continue
 if slug=='discovery':
  body=(root/'content/simulator.html').read_text()
  shell('lab/discovery/index.html','The Discovery Simulator','Compare illustrative traditional search results and AI-style answers across B2B services, finance and automotive, with interactive SEO, GEO and AEO explanations.',body)
  continue
 body=f'<div class="breadcrumbs"><a href="../index.html">The Lab</a> / {name}</div><section class="pagehero"><p class="eyebrow">EXPERIENCE PREVIEW · IN DEVELOPMENT</p><h1>{name}</h1><p>{tag}</p></section><section class="preview-note"><p class="eyebrow">WHAT THIS SPACE WILL EXPLORE</p><h2>{desc}</h2><p>The interactive demonstration is not available in this foundation release. Future examples will be labelled as illustrative and kept separate from client results, live search data, and website audit findings.</p><a class="button" href="../../work/index.html">Explore existing work ↗</a></section>'
 shell(f'lab/{slug}/index.html',name,desc,body,True)
for path,name,desc in [('lab/archive/index.html','Experiment Archive','A home for documented search hypotheses, methods, observations and limitations.'),('journal/index.html','Search Intelligence Journal','Notes on search strategy, content and the questions worth investigating.')]:
 body=f'<section class="pagehero"><p class="eyebrow">THE SEARCH LAB / RESEARCH</p><h1>{name}</h1><p>{desc}</p></section><section class="preview-note"><p class="eyebrow">IN PREPARATION</p><h2>'+('Evidence before conclusions.' if name=='Experiment Archive' else 'A place for considered answers.')+f'</h2><p>No '+('experiments' if name=='Experiment Archive' else 'articles')+f' have been published here yet. In the meantime, explore the existing project accounts.</p><a class="textlink" href="{rel("work/index.html",path)}">Read the selected work →</a></section>'
 shell(path,name,desc,body,True)
assets.joinpath('simulator-data.js').write_text('window.searchLabSimulator='+json.dumps(json.loads((root/'content/simulator.json').read_text()))+';\nwindow.searchLabAnnotations='+json.dumps(json.loads((root/'content/annotations.json').read_text()))+';')
assets.joinpath('decision-data.js').write_text('window.searchLabDecisions='+json.dumps(json.loads((root/'content/decision.json').read_text()))+';')
assets.joinpath('journey-data.js').write_text('window.searchLabJourneys='+json.dumps(json.loads((root/'content/journey.json').read_text()))+';')
import runpy
runpy.run_path(str(root/'xray_build.py'))
runpy.run_path(str(root/'evidence_build.py'),init_globals={'shell':shell})
runpy.run_path(str(root/'archive_build.py'),init_globals={'shell':shell})
runpy.run_path(str(root/'journal_build.py'),init_globals={'shell':shell,'rel':rel,'config':config})
runpy.run_path(str(root/'recovery_build.py'),init_globals={'shell':shell})
for name in ['system.css','navigation.js','simulator.js','xray.js','evidence.js','decision.js','observatory.js','journey.js','archive.js','journal.js','recovery.js']:
 if (root/name).exists():shutil.copy(root/name,assets/name)
