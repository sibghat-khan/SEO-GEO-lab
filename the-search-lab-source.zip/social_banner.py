from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
root=Path(__file__).parent
S=2
im=Image.new('RGB',(1200*S,627*S),'#F7F5EF');d=ImageDraw.Draw(im)
def font(size,serif=False,bold=False):
 name='Georgia' if serif else ('Arial Bold' if bold else 'Arial')
 return ImageFont.truetype('/System/Library/Fonts/Supplemental/'+name+'.ttf',size*S)
def text(x,y,t,size,color='#173E32',serif=False,bold=False):d.text((x*S,y*S),t,font=font(size,serif,bold),fill=color)
def line(points,color='#B7C8B9',width=1):d.line([(x*S,y*S) for x,y in points],fill=color,width=width*S)
d.rectangle((0,0,16*S,627*S),fill='#173E32')
text(66,48,'THE SEARCH LAB',25,bold=True)
text(66,91,'BY SIBGHAT KHAN',15,color='#626C63')
line([(66,135),(1134,135)])
text(66,180,'Helping businesses',58)
text(66,253,'get found.',80,serif=True)
text(70,363,'And turn visibility into growth.',32)
text(70,480,'SEO  /  GEO  /  ORGANIC GROWTH',19,bold=True)
line([(66,540),(1134,540)])
text(66,566,'Strategy. Evidence. Practical thinking.',19,color='#626C63')
# A restrained editorial search motif: discovery routes, not performance data.
d.rounded_rectangle((858*S,190*S,1134*S,438*S),radius=10*S,fill='#DCE6DD')
text(882,213,'DISCOVERY',15,bold=True)
d.rounded_rectangle((882*S,251*S,1110*S,303*S),radius=26*S,outline='#173E32',width=2*S)
d.ellipse((899*S,267*S,916*S,284*S),outline='#173E32',width=2*S)
line([(914,282),(922,290)],'#173E32',2)
text(937,266,'Search',18)
line([(996,303),(996,335),(923,335),(923,357)],'#173E32',2)
line([(996,335),(1070,335),(1070,357)],'#173E32',2)
text(894,372,'SEO',19,bold=True);text(1037,372,'AI',19,bold=True)
im=im.resize((1200,627),Image.Resampling.LANCZOS)
p=root/'content/search-lab-social.jpg';im.save(p,quality=94,optimize=True)
print(p)
